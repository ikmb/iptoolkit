"""An interface to query and retrive data from IEDB
"""
## LOAD THE MODULES
#------------------
from __future__ import annotations
import pandas as pd 
